### CH9434 SPI/I2C multifunction driver and applicaion

1. this contains ch9434 driver and gpio application, uart application please refer to: https://github.com/WCHSoftGroup/tty_uart

2. switch to "driver" directory to compile the ch9434 driver, please read README.md first

3. switch to "demo" directory to compile the gpio application, you can use gcc or cross-compile with cross-gcc, user should copy the library files from "lib" directory to "demo" directory
